﻿# SerialClient
###串口数据采集展示客户端

#依赖 
```
顺序最好不变
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pyqt5
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple serial==0.0.91
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pyserial==3.4
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple requests==2.14.2
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple requests-toolbelt==0.8.0
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple opencv-python==3.3.1.11
```

#运行

python main.py